import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from mpl_toolkits.mplot3d import axes3d

def k6_plot(self,p,l,theta,n):
    du = 180/np.pi
    # fig = plt.figure()
    ax1 = self.fig.add_subplot(1,2,1,projection="3d")
    ax2 = self.fig.add_subplot(1,2,2)
    ax1.set_xlim(-160,10)
    ax1.set_ylim(-10,80)
    ax1.set_zlim(-60,60)
    ax1.set_box_aspect([170,90,120])
    ax1.view_init(elev=30, azim=30)
    x = [p['2_i1'][0],p['2_i2'][0],p['2_i3'][0],p['2_j1'][0],p['2_j2'][0],p['2_j3'][0],p['2_k1'][0],p['2_k2'][0],p['2_k3'][0]]
    y = [p['2_i1'][1],p['2_i2'][1],p['2_i3'][1],p['2_j1'][1],p['2_j2'][1],p['2_j3'][1],p['2_k1'][1],p['2_k2'][1],p['2_k3'][1]]
    z = [p['2_i1'][2],p['2_i2'][2],p['2_i3'][2],p['2_j1'][2],p['2_j2'][2],p['2_j3'][2],p['2_k1'][2],p['2_k2'][2],p['2_k3'][2]]
    ax1.plot3D(x,y,z,'ko',markersize=3)

    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False
    ax2.plot(n*du,l['length_l'],lw=1,ls='-', color='purple',label='左')
    ax2.plot(n*du,l['length_m'],lw=1,ls='--',color='purple',label='中')
    ax2.plot(n*du,l['length_r'],lw=1,ls=':', color='purple',label='右')
    ax2.legend()
    ax2.grid()

    plot_dict = dict()
    def update(i):
        nonlocal plot_dict
        try:
            [plot_dict[i].remove() for i in plot_dict]
        except:
            pass

        x = [p['2_a'][i,0],p['2_b'][i,0],p['2_c'][i,0],p['2_d'][0],p['2_e'][0]]
        y = [p['2_a'][i,1],p['2_b'][i,1],p['2_c'][i,1],p['2_d'][1],p['2_e'][1]]
        z = [p['2_a'][i,2],p['2_b'][i,2],p['2_c'][i,2],p['2_d'][2],p['2_e'][2]]
        plot_dict['mechanism'], = ax1.plot3D(x,y,z,'-',color='slateblue')

        index_mechanism = ['a','b','c','d','e']
        for index in index_mechanism:
            try:
                plot_dict[index] = ax1.text(p[f'2_{index}'][i,0],p[f'2_{index}'][i,1],p[f'2_{index}'][i,2],index)
            except:
                plot_dict[index] = ax1.text(p[f'2_{index}'][0],p[f'2_{index}'][1],p[f'2_{index}'][2],index)


        x = [p['2_k1'][0],p['2_j1'][0],p['2_f1'][i,0],p['2_g1'][i,0],p['2_i1'][0]]
        y = [p['2_k1'][1],p['2_j1'][1],p['2_f1'][i,1],p['2_g1'][i,1],p['2_i1'][1]]
        z = [p['2_k1'][2],p['2_j1'][2],p['2_f1'][i,2],p['2_g1'][i,2],p['2_i1'][2]]
        plot_dict['rope1'], = ax1.plot3D(x,y,z,'r-',lw=1)
        x = [p['2_k2'][0],p['2_j2'][0],p['2_f2'][i,0],p['2_g2'][i,0],p['2_i2'][0]]
        y = [p['2_k2'][1],p['2_j2'][1],p['2_f2'][i,1],p['2_g2'][i,1],p['2_i2'][1]]
        z = [p['2_k2'][2],p['2_j2'][2],p['2_f2'][i,2],p['2_g2'][i,2],p['2_i2'][2]]
        plot_dict['rope2'], = ax1.plot3D(x,y,z,'r--',lw=1)
        x = [p['2_k3'][0],p['2_j3'][0],p['2_f3'][i,0],p['2_g3'][i,0],p['2_i3'][0]]
        y = [p['2_k3'][1],p['2_j3'][1],p['2_f3'][i,1],p['2_g3'][i,1],p['2_i3'][1]]
        z = [p['2_k3'][2],p['2_j3'][2],p['2_f3'][i,2],p['2_g3'][i,2],p['2_i3'][2]]
        plot_dict['rope3'], = ax1.plot3D(x,y,z,'r:',lw=1)

        x = [p['2_f1'][i,0],p['2_f2'][i,0],p['2_f3'][i,0],p['2_g1'][i,0],p['2_g2'][i,0],p['2_g3'][i,0]]
        y = [p['2_f1'][i,1],p['2_f2'][i,1],p['2_f3'][i,1],p['2_g1'][i,1],p['2_g2'][i,1],p['2_g3'][i,1]]
        z = [p['2_f1'][i,2],p['2_f2'][i,2],p['2_f3'][i,2],p['2_g1'][i,2],p['2_g2'][i,2],p['2_g3'][i,2]]
        plot_dict['points'], = ax1.plot3D(x,y,z,'o',color='m',markersize=3)

        index_mechanism = ['k1','j1','f1','g1','i1']
        for index in index_mechanism:
            try:
                plot_dict[index] = ax1.text(p[f'2_{index}'][i,0],p[f'2_{index}'][i,1],p[f'2_{index}'][i,2],index)
            except:
                plot_dict[index] = ax1.text(p[f'2_{index}'][0],p[f'2_{index}'][1],p[f'2_{index}'][2],index)
        
    ani = FuncAnimation(self.fig,update,frames=range(0,len(n),2),interval=10,repeat=True)
    # plt.show()
    
    self.canvas.draw()